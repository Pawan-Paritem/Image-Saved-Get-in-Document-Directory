//
//  CollectionViewCell.swift
//  FrameExtractFromVideo
//
//  Created by Pawan iOS on 29/11/2022.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    // MARK: - @IBOutlet & Variables
    @IBOutlet weak var frameImages: UIImageView!
    
    // MARK: - CollectionViewCell LifeCycle
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    // MARK: - registerCollectionViewCell
    class func registerCollectionViewCell(collectionView: UICollectionView, indexPath: IndexPath) -> CollectionViewCell {
        collectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Cell")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as? CollectionViewCell
        return cell!
    }
}
