//
//  PreviewViewController.swift
//  FrameExtractFromVideo
//
//  Created by Pawan iOS on 29/11/2022.
//

import UIKit

class PreviewViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    var getImageForPreview:[UIImage] = []
    var indexPathOfSelectedImage: Int? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        imageView.image = getImageForPreview[indexPathOfSelectedImage!]
    }

}
